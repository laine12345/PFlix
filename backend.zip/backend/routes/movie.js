const express = require('express')
const router = express.Router();


const {
    getMovies,
    getAdminMovies,
    newMovie,
    getSingleMovie,
    updateMovie,
    deleteMovie,
    createMovieReview,
    getMovieReviews,
    deleteReview

} = require('../controllers/movieController')

const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth');


router.route('/movies').get(getMovies);
router.route('/admin/movies').get(getAdminMovies);
router.route('/movie/:id').get(getSingleMovie);

router.route('/admin/movie/new').post(isAuthenticatedUser, authorizeRoles('admin'), newMovie);

router.route('/admin/movie/:id')
    .put(isAuthenticatedUser, authorizeRoles('admin'), updateMovie)
    .delete(isAuthenticatedUser, authorizeRoles('admin'), deleteMovie);


router.route('/movie/review').put(isAuthenticatedUser, createMovieReview)
router.route('/movie/reviews').get(isAuthenticatedUser, getMovieReviews)
router.route('/movie/reviews').delete(isAuthenticatedUser, deleteReview)

module.exports = router;
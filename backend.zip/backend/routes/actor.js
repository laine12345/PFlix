const express = require('express')
const router = express.Router();



const {
    getActors,
    getAdminActors,
    newActor,
    getSingleActor,
    updateActor,
    deleteActor,
    createActorReview,
    getActorReviews,
    deleteReview
} = require('../controllers/actorController')

const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth');


router.route('/actors').get(getActors);
router.route('/admin/actors').get(getAdminActors);
router.route('/actor/:id').get(getSingleActor);

router.route('/admin/actor/new').post(isAuthenticatedUser, authorizeRoles('admin'), newActor);

router.route('/admin/actor/:id')
    .put(isAuthenticatedUser, authorizeRoles('admin'), updateActor)
    .delete(isAuthenticatedUser, authorizeRoles('admin'), deleteActor);

router.route('/actor/review').put(isAuthenticatedUser, createActorReview)
router.route('/actor/reviews').get(isAuthenticatedUser, getActorReviews)
router.route('/actor/reviews').delete(isAuthenticatedUser, deleteReview)

module.exports = router;
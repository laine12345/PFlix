const Actor = require('../models/actor')

const ErrorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middlewares/catchAsyncErrors');
const APIFeatures = require('../utils/apiFeatures')
const cloudinary = require('cloudinary')
const swearjar = require('swearjar');

// Create new actor   =>   /api/v1/admin/actor/new
exports.newActor = catchAsyncErrors(async (req, res, next) => {

    let images = []
    if (typeof req.body.images === 'string') {
        images.push(req.body.images)
    } else {
        images = req.body.images
    }

    let imagesLinks = [];

    for (let i = 0; i < images.length; i++) {
        const result = await cloudinary.v2.uploader.upload(images[i], {
            folder: 'actors'
        });

        imagesLinks.push({
            public_id: result.public_id,
            url: result.secure_url
        })
    }

    req.body.images = imagesLinks
    req.body.user = req.user.id;

    const actor = await Actor.create(req.body);

    res.status(201).json({
        success: true,
        actor
    })
})


// Get all actors   =>   /api/v1/actors?keyword=apple
exports.getActors = catchAsyncErrors(async (req, res, next) => {

    const resPerPage = 4;
    const actorsCount = await Actor.countDocuments();

    const apiFeatures = new APIFeatures(Actor.find(), req.query)
        .search()
        .filter()

    let actors = await apiFeatures.query;
    let filteredActorsCount = actors.length;

    apiFeatures.pagination(resPerPage)
    actors = await apiFeatures.query;


    res.status(200).json({
        success: true,
        actorsCount,
        resPerPage,
        filteredActorsCount,
        actors
    })

})

// Get all actors (Admin)  =>   /api/v1/admin/actors
exports.getAdminActors = catchAsyncErrors(async (req, res, next) => {

    const actors = await Actor.find();

    res.status(200).json({
        success: true,
        actors
    })

})

// Get single actor details   =>   /api/v1/actor/:id
exports.getSingleActor = catchAsyncErrors(async (req, res, next) => {

    const actor = await Actor.findById(req.params.id);

    if (!actor) {
        return next(new ErrorHandler('Actor not found', 404));
    }


    res.status(200).json({
        success: true,
        actor
    })

})

// Update Actor   =>   /api/v1/admin/actor/:id
exports.updateActor = catchAsyncErrors(async (req, res, next) => {

    let actor = await Actor.findById(req.params.id);

    if (!actor) {
        return next(new ErrorHandler('Actor not found', 404));
    }

    let images = []
    if (typeof req.body.images === 'string') {
        images.push(req.body.images)
    } else {
        images = req.body.images
    }

    if (images !== undefined) {

        // Deleting images associated with the actor
        for (let i = 0; i < actor.images.length; i++) {
            const result = await cloudinary.v2.uploader.destroy(actor.images[i].public_id)
        }

        let imagesLinks = [];

        for (let i = 0; i < images.length; i++) {
            const result = await cloudinary.v2.uploader.upload(images[i], {
                folder: 'actors'
            });

            imagesLinks.push({
                public_id: result.public_id,
                url: result.secure_url
            })
        }

        req.body.images = imagesLinks

    }



    actor = await Actor.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    });

    res.status(200).json({
        success: true,
        actor
    })

})

// Delete Actor   =>   /api/v1/admin/actor/:id
exports.deleteActor = catchAsyncErrors(async (req, res, next) => {

    const actor = await Actor.findById(req.params.id);

    if (!actor) {
        return next(new ErrorHandler('Actor not found', 404));
    }

    // Deleting images associated with the actor
    for (let i = 0; i < actor.images.length; i++) {
        const result = await cloudinary.v2.uploader.destroy(actor.images[i].public_id)
    }

    await actor.remove();

    res.status(200).json({
        success: true,
        message: 'Actor is deleted.'
    })

})


// Create new review   =>   /api/v1/review
exports.createActorReview = catchAsyncErrors(async (req, res, next) => {

    const { rating, comment, actorId } = req.body;
    let filteredComment = swearjar.censor(comment);
    const review = {
        user: req.user._id,
        name: req.user.name,
        rating: Number(rating),
        comment: filteredComment
        
    }

    const actor = await Actor.findById(actorId);

    const isReviewed = actor.reviews.find(
        r => r.user.toString() === req.user._id.toString()
    )

    if (isReviewed) {
        actor.reviews.forEach(review => {
            if (review.user.toString() === req.user._id.toString()) {
                review.comment = filteredComment;
                review.rating = rating;
            }
        })

    } else {
        actor.reviews.push(review);
        actor.numOfReviews = actor.reviews.length
    }

    actor.ratings = actor.reviews.reduce((acc, item) => item.rating + acc, 0) / actor.reviews.length

    await actor.save({ validateBeforeSave: false });

    res.status(200).json({
        success: true
    })

})


// Get Actor Reviews   =>   /api/v1/reviews
exports.getActorReviews = catchAsyncErrors(async (req, res, next) => {
    const actor = await Actor.findById(req.query.id);

    res.status(200).json({
        success: true,
        reviews: actor.reviews
    })
})

// Delete Actor Review   =>   /api/v1/reviews
exports.deleteReview = catchAsyncErrors(async (req, res, next) => {

    const actor = await Actor.findById(req.query.actorId);

    console.log(actor);

    const reviews = actor.reviews.filter(review => review._id.toString() !== req.query.id.toString());

    const numOfReviews = reviews.length;

    const ratings = actor.reviews.reduce((acc, item) => item.rating + acc, 0) / reviews.length

    await Actor.findByIdAndUpdate(req.query.actorId, {
        reviews,
        ratings,
        numOfReviews
    }, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    })

    res.status(200).json({
        success: true
    })
})

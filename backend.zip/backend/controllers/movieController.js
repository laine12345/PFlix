const Movie = require('../models/movie')

const ErrorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middlewares/catchAsyncErrors');
const APIFeatures = require('../utils/apiFeatures')
const cloudinary = require('cloudinary')
const swearjar = require('swearjar');
// Create new movie   =>   /api/v1/admin/movie/new
exports.newMovie = catchAsyncErrors(async (req, res, next) => {

    let images = []
    if (typeof req.body.images === 'string') {
        images.push(req.body.images)
    } else {
        images = req.body.images
    }

    let imagesLinks = [];

    for (let i = 0; i < images.length; i++) {
        const result = await cloudinary.v2.uploader.upload(images[i], {
            folder: 'movies'
        });

        imagesLinks.push({
            public_id: result.public_id,
            url: result.secure_url
        })
    }

    req.body.images = imagesLinks
    req.body.user = req.user.id;

    const movie = await Movie.create(req.body);

    res.status(201).json({
        success: true,
        movie
    })
})


// Get all movies   =>   /api/v1/movies?keyword=apple
exports.getMovies = catchAsyncErrors(async (req, res, next) => {

    const resPerPage = 4;
    const moviesCount = await Movie.countDocuments();

    const apiFeatures = new APIFeatures(Movie.find(), req.query)
        .search()
        .filter()

    let movies = await apiFeatures.query;
    let filteredMoviesCount = movies.length;

    apiFeatures.pagination(resPerPage)
    movies = await apiFeatures.query;


    res.status(200).json({
        success: true,
        moviesCount,
        resPerPage,
        filteredMoviesCount,
        movies
    })

})

// Get all movies (Admin)  =>   /api/v1/admin/movies
exports.getAdminMovies = catchAsyncErrors(async (req, res, next) => {

    let sortBy = {createdAt:1}
    let limit = 0
    if (req.query.limit){
        limit = 10
    }
    // const movies = await Movie.find();
        if (req.query.sort=='ratings'){
        sortBy = {ratings:-1}
        }
        if (req.query.sort=='numOfReviews'){
            sortBy = {numOfReviews:-1}
                }
                if (req.query.sort=='grossincome'){
                    sortBy = {grossincome:-1}
                        }
    const movies = await Movie.find().sort(sortBy).limit(limit);
        res.status(200).json({
            success: true,
            movies
        })

    })

// Get single movie details   =>   /api/v1/movie/:id
exports.getSingleMovie = catchAsyncErrors(async (req, res, next) => {

    const movie = await Movie.findById(req.params.id);

    if (!movie) {
        return next(new ErrorHandler('Movie not found', 404));
    }


    res.status(200).json({
        success: true,
        movie
    })

})

// Update Movie   =>   /api/v1/admin/movie/:id
exports.updateMovie = catchAsyncErrors(async (req, res, next) => {

    let movie = await Movie.findById(req.params.id);

    if (!movie) {
        return next(new ErrorHandler('Movie not found', 404));
    }

    let images = []
    if (typeof req.body.images === 'string') {
        images.push(req.body.images)
    } else {
        images = req.body.images
    }

    if (images !== undefined) {

        // Deleting images associated with the movie
        for (let i = 0; i < movie.images.length; i++) {
            const result = await cloudinary.v2.uploader.destroy(movie.images[i].public_id)
        }

        let imagesLinks = [];

        for (let i = 0; i < images.length; i++) {
            const result = await cloudinary.v2.uploader.upload(images[i], {
                folder: 'movies'
            });

            imagesLinks.push({
                public_id: result.public_id,
                url: result.secure_url
            })
        }

        req.body.images = imagesLinks

    }



    movie = await Movie.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    });

    res.status(200).json({
        success: true,
        movie
    })

})

// Delete Movie   =>   /api/v1/admin/movie/:id
exports.deleteMovie = catchAsyncErrors(async (req, res, next) => {

    const movie = await Movie.findById(req.params.id);

    if (!movie) {
        return next(new ErrorHandler('Movie not found', 404));
    }

    // Deleting images associated with the movie
    for (let i = 0; i < movie.images.length; i++) {
        const result = await cloudinary.v2.uploader.destroy(movie.images[i].public_id)
    }

    await movie.remove();

    res.status(200).json({
        success: true,
        message: 'Movie is deleted.'
    })

})


// Create new review   =>   /api/v1/review
exports.createMovieReview = catchAsyncErrors(async (req, res, next) => {

    const { rating, comment, movieId } = req.body;
let filteredComment = swearjar.censor(comment);
    const review = {
        user: req.user._id,
        name: req.user.name,
        rating: Number(rating),
        comment: filteredComment
    }

    const movie = await Movie.findById(movieId);

    const isReviewed = movie.reviews.find(
        r => r.user.toString() === req.user._id.toString()
    )

    if (isReviewed) {
        movie.reviews.forEach(review => {
            if (review.user.toString() === req.user._id.toString()) {
                review.comment = filteredComment;
                review.rating = rating;
            }
        })

    } else {
        movie.reviews.push(review);
        movie.numOfReviews = movie.reviews.length
    }

    movie.ratings = movie.reviews.reduce((acc, item) => item.rating + acc, 0) / movie.reviews.length

    await movie.save({ validateBeforeSave: false });

    res.status(200).json({
        success: true
    })

})


// Get Movie Reviews   =>   /api/v1/reviews
exports.getMovieReviews = catchAsyncErrors(async (req, res, next) => {
    const movie = await Movie.findById(req.query.id);

    res.status(200).json({
        success: true,
        reviews: movie.reviews
    })
})

// Delete Movie Review   =>   /api/v1/reviews
exports.deleteReview = catchAsyncErrors(async (req, res, next) => {

    const movie = await Movie.findById(req.query.movieId);

    console.log(movie);

    const reviews = movie.reviews.filter(review => review._id.toString() !== req.query.id.toString());

    const numOfReviews = reviews.length;

    const ratings = movie.reviews.reduce((acc, item) => item.rating + acc, 0) / reviews.length

    await Movie.findByIdAndUpdate(req.query.movieId, {
        reviews,
        ratings,
        numOfReviews
    }, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    })

    res.status(200).json({
        success: true
    })
})
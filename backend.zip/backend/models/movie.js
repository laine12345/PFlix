const mongoose = require('mongoose')

const movieSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Please enter movie title'],
        trim: true,

    },
    releasedDate: {
        type: String,
        required: [true, 'Please enter movie released date'],
       
        
    },
    duration: {
        type: Number,
        required: [true, 'Please enter movie duration'],
      
        default: 0.0
    },
    description: {
        type: String,
        required: [true, 'Please enter movie description'],
    },
    ratings: {
        type: Number,
        default: 0
    },
    grossincome: {
        type: Number,
        required: [true, 'Please enter gross income'],
      
        default: 0.0
    },
    images: [
        {
            public_id: {
                type: String,
                required: true
            },
            url: {
                type: String,
                required: true
            },
        }
    ],
    category: {
        type: String,
        required: [true, 'Please select category for this movie'],
        enum: {
            values: [
                'Comedy',
                'Drama',
                'Horror',
                'Sci-fi',
                'Action',
            ],
            message: 'Please select correct category for movie'
        }
    },
    
    numOfReviews: {
        type: Number,
        default: 0
    },
     
    ratings: {
        type: Number,
        default: 0
    },
    reviews: [
        {
            user: {
                type: mongoose.Schema.ObjectId,
                ref: 'User',
                required: true
            },
            name: {
                type: String,
                required: true
            },
            rating: {
                type: Number,
                required: true
            },
            comment: {
                type: String,
                required: true
            }
        }
    ],
    user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: false
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
})

module.exports = mongoose.model('Movie', movieSchema);
const mongoose = require('mongoose')

const actorSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please enter actor name'],
        trim: true,
        maxLength: [100, 'Actor name cannot exceed 100 characters']
    },
    careerBio: {
        type: String,
        required: [true, 'Please enter actor career Bio'],
    },
    
    images: [
        {
            public_id: {
                type: String,
                required: true
            },
            url: {
                type: String,
                required: true
            },
        }
    ],
    
    numOfReviews: {
        type: Number,
        default: 0
    },
     
    ratings: {
        type: Number,
        default: 0
    },
    reviews: [
        {
            user: {
                type: mongoose.Schema.ObjectId,
                ref: 'User',
                required: true
            },
            name: {
                type: String,
                required: true
            },
            rating: {
                type: Number,
                required: true
            },
            comment: {
                type: String,
                required: true
            }
        }
    ],
    user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: false
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
})

module.exports = mongoose.model('Actor', actorSchema);